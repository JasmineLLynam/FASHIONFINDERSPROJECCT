# --- !fashion finders dataset

# --- !Ups

insert into product(id,name,category,description,stock,price) values ( 1, 'Embroidered Hem Skinny','Jeans', 'Blue Embroidered Jenna Jeans',55,12.99 );
insert into product(id,name,category,description,stock,price) values ( 2, 'Pink Slim Leg Trousers','Trousers', 'Pale Pink Slim Leg',87,19.99 );
insert into product(id,name,category,description,stock,price) values ( 3, 'Off White Metal Ring Cami','Tops','Metail Ring Cross Back Cami', 12, 2.99 );
insert into product(id,name,category,description,stock,price) values ( 4, 'Light Brown Cami','Tops', 'Light Brown Square Neck Cropped Cami Top',55,15.99 );
insert into product(id,name,category,description,stock,price) values ( 5, 'Khaki Cross Heels','Shoes', 'Khaki Suedette Cross Strap Pointed Heels',27,28.99 );
insert into product(id,name,category,description,stock,price) values ( 6, 'Rust Sleeve Top','Tops', 'Rust Embroidered Front Balloon Sleeve top',13,26.99 );
insert into product(id,name,category,description,stock,price) values ( 7, 'Grey NYC T-shirt','Tops', 'Pale Grey NYC Photographic T-shirt',45,23.99 );
insert into product(id,name,category,description,stock,price) values ( 8, 'Black Bag','Accessories','BLack Fringe Trim Hobo Bag',28,55.99 );
insert into product(id,name,category,description,stock,price) values ( 9, 'Nude Block Heel','Shoes','Nude Suedette Slim Block Heel Strappy Sandals',33,45.99 );
insert into product(id,name,category,description,stock,price) values ( 10, 'Blue Tie Dress','Dress','Blue Tie Front Bodycon Dress',30,29.99 );

