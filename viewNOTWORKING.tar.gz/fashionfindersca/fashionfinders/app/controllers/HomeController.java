package controllers;

import play.mvc.*;
import models.sales;
import views.html.*;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result index() {
        return ok(index.render("Hello"));
    }

    public Result sales() {

        sales s = new sales();

        s.setId(1L);
        s.setName("LCD TV");
        s.SetCategory("Home Entertainment");
        s.setDescription("Sony 55 inch LCD TV");
        s.setStock(10);
        s.setPrice(850.00);
    
        return ok(sales.render());
    }

    public Result women() {
        return ok(women.render());
    }
 
    public Result viewmen() {
        return ok(viewmen.render());
    }

    public Result accessories() {
        return ok(accessories.render());
    }

}

