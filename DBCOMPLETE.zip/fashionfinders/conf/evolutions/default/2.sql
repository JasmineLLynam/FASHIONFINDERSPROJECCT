# --- Sample dataset

# --- !Ups

insert into product (id,name,category,description,stock,price) values ( 1, 'Black Shirred Bardot', 'Tops' , 'Neck crop top', 25,12.99 );
insert into product (id,name,category,description,stock,price) values ( 2, 'Blue FLoral Tie Front', 'Playsuit' , 'Tie front playsuit', 50,29.99 );
insert into product (id,name,category,description,stock,price) values ( 3, 'Pale blue dress', 'Dress' , 'Lace up back maxi dress', 32.99 );
insert into product (id,name,category,description,stock,price) values ( 4, 'Navy Border print', 'Dress' , 'Hanky Hem bustier', 78, 26.99 );
insert into product (id,name,category,description,stock,price) values ( 5, 'Brown Stripe Tie', 'shorts' , 'Tie waist shorts', 65,25.99 );
insert into product (id,name,category,description,stock,price) values ( 6, 'White Nevada', 'Tank top' , 'Nevada print crochet side tank', 32,19.99 );