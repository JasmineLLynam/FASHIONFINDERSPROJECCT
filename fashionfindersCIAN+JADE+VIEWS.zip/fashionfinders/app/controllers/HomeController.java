package controllers;

import play.mvc.*;
import models.Product;

import views.html.*;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result index() {
        return ok(index.render("Hello world"));
    }


    

    public Result products() {

        //create a new product
        Product p = new Product();

        //set propertes for p 
        p.setId(1L);
        p.setName("LCD TV");
        p.setCategory("Home Entertainment");
        p.setDescription("Sony 55 inch LCD TV");
        p.setStock(18);
        p.setPrice(850.00);

        //or create a new product by calling the constructor
        Product p2 = new Product(1L, "LCD TV", "Home", "LG 55inch OLED TV", 18, 2000.00);

        return ok(products.render(p));
    }


    public Result women() {
        return ok(women.render());
    }
 
    public Result viewmen() {
        return ok(viewmen.render());
    }

    public Result accessories() {
        return ok(accessories.render());
    }


 
}
